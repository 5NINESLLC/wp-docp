/**
 * Time Chart
 *
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 *
 * @param location
 * @param data
 * @constructor
 */
var GFChart_Time = {

    /**
     * ID of the div where this chart will be rendered
     */
    location: '',

    data: '',

    options: '',

    init: function () {

        var obj = this;

        google.load( 'visualization', '1', {
            'packages': ['corechart'], 'callback': function () {
                obj.drawChart()
            }
        } );

    },

    formatData: function () {
    },

    drawChart: function () {

        var data_table = new google.visualization.DataTable( this.data );

        var location = document.getElementById( this.location );

        switch( this.options.gfchart_display_type ) {

            case 'bar':

                if ('horizontal' == this.options.bars) {

                    var chart = new google.visualization.BarChart(location);

                }
                else {

                    var chart = new google.visualization.ColumnChart(location);

                }

                break;

            case 'line':

                var chart = new google.visualization.LineChart(location);

                break;
        }

        chart.draw( data_table, this.options );

        jQuery( '#' + this.location ).show();

    }

};