/**
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */

jQuery( document ).ready( function() {

    gfchart.addAction( 'gfchart_select_data_init', 'gfchart_time_select_data_init' );

    jQuery('#gfchart-time-yaxis').on('change', gfchart_time_toggle_xaxis_sum_field);

});

/**
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 *
 * @param chart_type
 */
function gfchart_time_select_data_init( chart_type ) {

    if ( 'time' === chart_type ) {

        jQuery('#gfchart-time-additional-filters').click({ chart_type: 'time' }, gfchart_admin_chart_config.gfchart_toggle_filters );

        if ('sum' === jQuery('#gfchart-time-yaxis').val()) {

            jQuery('#gfchart-time-xaxis-sum-field-container').show();

        }

    }

}

/**
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
function gfchart_time_toggle_xaxis_sum_field() {

    if ('sum' === jQuery(this).val()) {

        jQuery('#gfchart-time-xaxis-sum-field-container').show('slow');

    }
    else {

        jQuery('#gfchart-time-xaxis-sum-field-container').hide('slow');

        gfchart_time_clear_xaxis_sum_field();

    }

}

/**
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
function gfchart_time_clear_xaxis_sum_field() {

    jQuery('#gfchart-time-xaxis-sum-field').val('');

}