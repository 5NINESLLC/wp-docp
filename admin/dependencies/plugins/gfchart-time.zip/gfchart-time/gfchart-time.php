<?php
/**
 * @wordpress-plugin
 * Plugin Name: GFChart Charting vs Time Add-On
 * Plugin URI: http://gfchart.com/
 * Description: Chart entries vs time
 * Version: 0.8
 * Author: gravity+
 * Author URI: gravityplus.pro
 * Text Domain: gfchart-time
 * Domain Path: /languages
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package   GFChart-Time
 * @version   0.8
 * @author    gravity+ <support@gravityplus.pro>
 * @license   GPL-2.0+
 * @link      https://gravityplus.pro
 * @copyright 2017-2020 gravity+
 *
 * last updated: August 27, 2020
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'GFCHART_TIME_CURRENT_VERSION', '0.8' );

define( 'GFCHART_TIME_FILE', __FILE__ );

define( 'GFCHART_TIME_PATH', plugin_dir_path( __FILE__ ) );

define( 'GFCHART_TIME_URL', plugin_dir_url( __FILE__ ) );

define( 'GFCHART_TIME_SLUG', plugin_basename( dirname( __FILE__ ) ) );

define( 'GFCHART_TIME_EDD_STORE_URL', 'http://gfchart.com/' );

define( 'GFCHART_TIME_EDD_ITEM_NAME', 'GFChart Charting vs Time Add-On' );

define( 'GFCHART_TIME_EDD_ITEM_ID', 7862 );

/**
 * Class GFChart_Time
 *
 * @since  0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
class GFChart_Time {

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	private $min_gf_version = '2.4';

	/**
	 * GFChart_Time constructor.
	 *
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function __construct() {
	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function run() {

		add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ) );

		add_action( 'admin_init', array( $this, 'admin_init' ) );

	}

	/**
	 * Automatic updates
	 *
	 * @since
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function admin_init() {

		if ( ! class_exists( 'GFChart_EDD_SL_Plugin_Updater' ) ) {

			include( GFCHART_TIME_PATH . 'class-plugin-updater.php' );

		}


		if ( class_exists( 'GFChart' ) ) {

			global $gfp_gfchart;

			$license_key = trim( $gfp_gfchart->get_addon_object()->get_plugin_setting( 'license_key' ) );

			//TODO do I need to check license status?

			if ( ! empty( $license_key ) ) {

				$edd_updater = new GFChart_EDD_SL_Plugin_Updater(
					GFCHART_TIME_EDD_STORE_URL,
					GFCHART_TIME_FILE,
					array(
						'version' => GFCHART_TIME_CURRENT_VERSION,
						'license' => $license_key,
						'item_id' => GFCHART_TIME_EDD_ITEM_ID,
						'author'  => 'Mensard with gravity+',
						'url'     => home_url()
					)
				);

			}

		}

	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function plugins_loaded() {

		add_filter( 'gfchart_chart_types', array( $this, 'gfchart_chart_types' ) );

		add_filter( 'gfchart_config_file_paths', array( $this, 'gfchart_config_file_paths' ) );

		add_action( 'gfchart_admin_enqueue_scripts', array( $this, 'gfchart_admin_enqueue_scripts' ) );

		add_action( 'gfchart_shortcode_scripts', array( $this, 'gfchart_shortcode_scripts' ) );


	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function gfchart_chart_types( $chart_types ) {

		$chart_types = array_merge( $chart_types, array(
			array(
				'id'                   => 'time',
				'label'                => __( 'vs Time', 'gfchart' ),
				'icon_element'         => 'span',
				'icon_class'           => 'dashicons dashicons-clock',
				'data_retriever'       => array( $this, 'get_time_chart_data' ),
				'data_formatter'       => array( $this, 'format_time_chart_data' ),
				'format_chart_options' => array( $this, 'format_time_chart_options' )
			),
		) );

		return $chart_types;

	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function gfchart_config_file_paths( $config_paths ) {

		$config_paths[] = GFCHART_TIME_PATH . "includes/views/config-sections/";


		return $config_paths;
	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function gfchart_admin_enqueue_scripts() {

		global $post;

		if ( ! empty( $post->ID ) ) {

			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			wp_enqueue_script( 'gfchart-time-admin-chart-config-js', GFCHART_TIME_URL . "/js/admin-chart-config{$suffix}.js", array(
				'gfchart-admin-chart-config-js'
			), GFCHART_TIME_CURRENT_VERSION, true );

			$this->gfchart_shortcode_scripts();

		}

	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function gfchart_shortcode_scripts() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script( 'gfchart-time-draw', GFCHART_TIME_URL . "/js/gfchart-draw{$suffix}.js", array(
			'gfchart-draw'
		), GFCHART_TIME_CURRENT_VERSION, true );

	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function get_time_chart_data( $gfchart_config, $source_form_id, $filters ) {

		$source_field_id = $gfchart_config['xaxis-main-field'];

		if ( empty( $source_field_id ) ) {

			return __( 'Error obtaining data.', 'gfchart' );

		}

		global $gfp_gfchart;

		$data = array();


		$month = date( 'F' );

		if ( 'date_created' == $source_field_id ) {

			$gfchart_config['date_filter_start'] = "first day of {$month} last year";

		} else {

			add_filter( 'gfchart_api_get_entries_query', $date_field_condition_callback = function ( $q, $sc ) use ( $source_field_id, $month ) {

				/**
				 * @var GF_Query $q
				 */
				$date_field_condition = new GF_Query_Condition(
					new GF_Query_Column( $source_field_id ),
					GF_Query_Condition::GTE,
					new GF_Query_Literal( GFChart_API::format_date_for_search( "first day of {$month} last year" ) ) );

				$query_parameters = $q->_introspect();

				$q->where( \GF_Query_Condition::_and( $query_parameters['where'], $date_field_condition ) );


				return $q;
			}, 10, 2 );

		}


		$results = $gfp_gfchart->get_data_object()->build_and_execute_gf_query( $gfchart_config, $source_form_id, $filters );

		if ( isset( $date_field_condition_callback ) ) {

			remove_filter( 'gfchart_api_get_entries_query', $date_field_condition_callback );

		}


		if ( empty( $results ) || ! is_array( $results ) ) {

			return $results;

		}


		$segmented = ! empty( $gfchart_config['xaxis-segment-field'] );


		foreach ( $results as $result ) {

			if ( empty( $result[ $source_field_id ] ) ) {

				continue;
			}

			$mysql_date = $result[ $source_field_id ];

			/**
			 * @see GFCommon::format_date()
			 */

			$gmt_date = gmdate( 'Y-m-d H:i:s', mysql2date( 'G', $mysql_date ) );

			$local_date = get_date_from_gmt( $gmt_date );

			$data[] = array(
				'entry_id' => $result['id'],
				'date'     => $local_date
			);


		}


		if ( ! empty( $gfchart_config['xaxis-sum-field'] ) ) {

			$data = $gfp_gfchart->get_data_object()->add_sum_field_value_to_results( $results, $data, $gfchart_config['xaxis-sum-field'] );

		}

		if ( 'count' == $gfchart_config['yaxis'] ) {

			$data = $this->count_results( $data, $segmented );

		} else {

			$data = $this->sum_results( $data, $segmented );

		}


		return $data;

	}

	/**
	 * Format time chart data for Google Charts rendering
	 *
	 * @param array $data
	 * @param array $chart_config
	 *
	 * @return mixed
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @since  0.3
	 *
	 */
	public function format_time_chart_data( $data, $chart_config = array() ) {

		return GFChart_API::format_bar_chart_data( $data );
	}

	/**
	 * @param $results
	 *
	 * @return array
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 */
	public function count_results( $results, $segmented = false ) {

		$current_year = date( 'Y' );

		$data = array(
			'segments' => array(),
			'results'  => array(
				"{$current_year}-1"  => 0,
				"{$current_year}-2"  => 0,
				"{$current_year}-3"  => 0,
				"{$current_year}-4"  => 0,
				"{$current_year}-5"  => 0,
				"{$current_year}-6"  => 0,
				"{$current_year}-7"  => 0,
				"{$current_year}-8"  => 0,
				"{$current_year}-9"  => 0,
				"{$current_year}-10" => 0,
				"{$current_year}-11" => 0,
				"{$current_year}-12" => 0,
			)
		);


		$last_12_months = $this->get_last_12_months();

		if ( ! empty( $last_12_months ) ) {

			$data['results'] = $last_12_months;

		}

		foreach ( $results as $result ) {

			$parsed_date = date_parse( $result['date'] );

			$data['results']["{$parsed_date['year']}-{$parsed_date['month']}"] += 1;

		}


		return $data;
	}

	/**
	 * @param $results
	 *
	 * @return array
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 */
	public function sum_results( $results, $segmented = false ) {

		$current_year = date( 'Y' );

		$data = array(
			'segments' => array(),
			'results'  => array(
				"{$current_year}-1"  => 0,
				"{$current_year}-2"  => 0,
				"{$current_year}-3"  => 0,
				"{$current_year}-4"  => 0,
				"{$current_year}-5"  => 0,
				"{$current_year}-6"  => 0,
				"{$current_year}-7"  => 0,
				"{$current_year}-8"  => 0,
				"{$current_year}-9"  => 0,
				"{$current_year}-10" => 0,
				"{$current_year}-11" => 0,
				"{$current_year}-12" => 0,
			)
		);


		$last_12_months = $this->get_last_12_months();

		if ( ! empty( $last_12_months ) ) {

			$data['results'] = $last_12_months;

		}

		foreach ( $results as $result ) {

			$parsed_date = date_parse( $result['date'] );

			$data['results']["{$parsed_date['year']}-{$parsed_date['month']}"] += $result['sum_value'];

		}


		return $data;
	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	private function get_last_12_months() {

		$last_12_months = array();


		$current_year = date( 'Y' );

		$current_month = date( 'n' );

		$last_year = $current_year - 1;

		$months_left_in_the_year = 12 - $current_month;

		if ( $months_left_in_the_year > 0 ) {

			for ( $i = 0; $i <= $months_left_in_the_year; $i ++ ) {

				$key = $current_month + $i;

				$last_12_months["{$last_year}-{$key}"] = 0;

			}

			for ( $i = 1; $i <= $current_month; $i ++ ) {

				$last_12_months["{$current_year}-{$i}"] = 0;

			}

		}


		return $last_12_months;
	}

	/**
	 * @since  0.1
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 */
	public function format_time_chart_options( $chart_config, $default_options ) {

		$default_options['legend']['position'] = $chart_config['legend'];

		$default_options['vAxis'] = array( 'title' => $chart_config['yaxis-label'] );

		$default_options['hAxis'] = array(
			'title'            => $chart_config['xaxis-label'],
			'slantedText'      => 'true',
			'slantedTextAngle' => '45'
		);

		$default_options['hAxis']['showTextEvery'] = '1';

		switch ( rgar( $chart_config, 'chart-display-type' ) ) {

			case 'line':

				$default_options['gfchart_display_type'] = 'line';

				break;

			case 'bar':
			case '':

				$default_options['gfchart_display_type'] = 'bar';

				$default_options['bars'] = $chart_config['orientation'];

				if ( ! empty( $chart_config['xaxis-segment-display'] ) ) {

					switch ( $chart_config['xaxis-segment-display'] ) {

						case 'stackabsolute':

							$default_options['isStacked'] = 'true';

							break;

						case 'stackpercent':

							$default_options['isStacked'] = 'percent';

							break;

					}

				}

				break;
		}


		$additional_options = json_decode( str_replace( array(
			"\r",
			"\n"
		), '', $chart_config['additional_code'] ), true );

		$chart_options = wp_parse_args( $additional_options, $default_options );

		return $chart_options;

	}
}

$gfp_gfchart_time = new GFChart_Time();

$gfp_gfchart_time->run();