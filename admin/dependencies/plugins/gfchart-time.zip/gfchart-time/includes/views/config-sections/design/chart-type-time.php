<?php
/**
 * GFChart Configuration Metabox — Design Tab — Time Chart Type Basic Settings
 *
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
?>
<h1><?php _e( 'Time', 'gfchart-time' )?></h1>
<table class="form-table striped">
	<tbody>
    <tr>
        <th><?php _e( 'Display Type', 'gfchart-time' ) ?></th>
        <td>
            <select name="gfchart_config[chart-display-type]">
                <option value="bar" <?php selected( rgar( $gfchart_config, 'chart-display-type' ), 'bar', true ); ?>><?php _e( 'Bar', 'gfchart-time' ) ?>
                </option>
                <option value="line" <?php selected( rgar( $gfchart_config, 'chart-display-type' ), 'line', true ); ?>><?php _e( 'Line', 'gfchart-time' ) ?>
                </option>
            </select>
        </td>
    </tr>
	<tr>
		<th><?php _e( 'Bar Orientation', 'gfchart-time' ) ?></th>
		<td>
			<label for="gfchart-chart-type-time-orientation"><?php _e( 'Vertical', 'gfchart-time' ) ?></label>
						<input
							type="radio" id="gfchart-chart-type-time-orientation-vertical" name="gfchart_config[orientation]"
							value="vertical" <?php checked( rgar( $gfchart_config, 'orientation' ), 'vertical', true ); ?> />
			<label for="gfchart-chart-type-time-orientation"><?php _e( 'Horizontal', 'gfchart-time' ) ?></label>
									<input
										type="radio" id="gfchart-chart-type-time-orientation-horizontal" name="gfchart_config[orientation]"
										value="horizontal" <?php checked( rgar( $gfchart_config, 'orientation' ), 'horizontal', true ); ?> />

		</td>
	</tr>
	<tr>
		<th><?php _e( 'Legend', 'gfchart-time' ) ?></th>
		<td>
			<select name="gfchart_config[legend]">
				<option value="none" <?php selected( rgar( $gfchart_config, 'legend' ), 'none', true ); ?>><?php _e( 'None', 'gfchart-time' ) ?>
				</option>
				<option value="bottom" <?php selected( rgar( $gfchart_config, 'legend' ), 'bottom', true ); ?>><?php _e( 'Bottom', 'gfchart-time' ) ?>
				</option>
				<option value="top" <?php selected( rgar( $gfchart_config, 'legend' ), 'top', true ); ?>><?php _e( 'Top', 'gfchart-time' ) ?></option>
				<option value="right"<?php selected( rgar( $gfchart_config, 'legend' ), 'right', true ); ?>><?php _e( 'Right', 'gfchart-time' ) ?>
				</option>
				<option value="left" <?php selected( rgar( $gfchart_config, 'legend' ), 'left', true ); ?>><?php _e( 'Left', 'gfchart-time' ) ?></option>
				<option value="in" <?php selected( rgar( $gfchart_config, 'legend' ), 'in', true ); ?>><?php _e( 'In', 'gfchart-time' ) ?>
				</option>
			</select>
		</td>
	</tr>
	</tbody>
</table>