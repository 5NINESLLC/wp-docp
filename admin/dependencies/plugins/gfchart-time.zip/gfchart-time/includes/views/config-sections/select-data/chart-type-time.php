<?php
/**
 * GFChart Configuration Metabox — Select Data Tab — Time Chart Type Basic Settings
 *
 * @since 0.1
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
?>
<h1><?php _e( 'Time', 'gfchart-time' ) ?></h1>

<table class="form-table striped">

	<tbody>

	<tr>
		<th><?php _e( 'Source Form', 'gfchart-time' ) ?></th>
		<td colspan="4">
			<?php esc_html_e(  $source_form[ 'title' ] )?>
		</td>
	</tr>

	<tr>
		<th><?php _e( 'x-axis', 'gfchart-time' ) ?> (<?php _e( 'main field', 'gfchart-time' ) ?>)</th>
		<td>
			<select id="gfchart-time-xaxis-main-field" name="gfchart_config[xaxis-main-field]">
				<option value="date_created" <?php selected( rgar( $gfchart_config, 'xaxis-main-field' ), 'date_created', true ) ?>><?php _e( 'Form Submission Date', 'gfchart-time' ); ?></option>
<?php
$fields  = GFAPI::get_fields_by_type( $source_form, array( 'date' ) );

foreach ( $fields as $field ) {
    ?>
    <option value="<?php esc_attr_e(  $field->id ) ?>" <?php selected( rgar( $gfchart_config, 'xaxis-main-field' ), $field->id, true ) ?>><?php esc_html_e(  RGFormsModel::get_label( $field ) ) ?></option>

	<?php
}

?>
			</select>
		</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>

	<tr>
		<th><?php _e( 'y-axis', 'gfchart-time' ) ?></th>
		<td colspan="4"><?php _e( 'Count or sum entries?', 'gfchart-time' ) ?><br/>
			<select id="gfchart-time-yaxis" name="gfchart_config[yaxis]">
				<option value="count" <?php selected( rgar( $gfchart_config, 'yaxis' ), 'count', true ) ?>><?php _e( 'count', 'gfchart-time' ) ?></option>
				<option value="sum" <?php selected( rgar( $gfchart_config, 'yaxis' ), 'sum', true ) ?>><?php _e( 'sum', 'gfchart-time' ) ?></option>
			</select>
		</td>
	</tr>

	<tr id="gfchart-time-xaxis-sum-field-container" style="display:none;">
			<th><?php _e( 'Field to sum', 'gfchart-time' ) ?></th>
			<td colspan="4">
				<select id="gfchart-time-xaxis-sum-field" name="gfchart_config[xaxis-sum-field]">
					<option value=""></option>
					<?php foreach ( $form_fields as $field ) {

						$field_id    = $field[ 0 ];
						$field_label = esc_html( GFCommon::truncate_middle( $field[ 1 ], 40 ) );
						?>
						<option
							value="<?php esc_attr_e(  $field_id ) ?>" <?php selected( rgar( $gfchart_config, 'xaxis-sum-field' ), $field_id, true ) ?>><?php esc_html_e(  $field_label ) ?></option>

					<?php } ?>
				</select>
			</td>
		</tr>

	<tr>
		<th><?php _e( 'Entries for logged-in user only?', 'gfchart-time' ) ?></th>
		<td colspan="4">
			<input type="checkbox" id="gfchart-time-user-only" name="gfchart_config[user_only]"
			       value="1" <?php checked( rgar( $gfchart_config, 'user_only' ), '1' ) ?>" />
		</td>
	</tr>

	<tr>
		<th><?php _e( 'Payment Status', 'gfchart-time' ) ?></th>
				<td>
					<input type="text" id="gfchart-time-payment-status" name="gfchart_config[payment_status]"
					       value="<?php esc_attr_e(  rgar( $gfchart_config, 'payment_status' ) ) ?>"/>
				</td>

		</tr>

	<tr>
		<th><?php _e( 'Enable additional filters?', 'gfchart-time' ) ?></th>
		<td colspan="4">
			<input type="checkbox" id="gfchart-time-additional-filters" name="gfchart_config[additional_filters]"
			       value="1" <?php checked( rgar( $gfchart_config, 'additional_filters' ), '1' ) ?>" />

			<div id="gfchart_time_entry_filters" class="hide-if-js"
			     style="<?php echo rgar( $gfchart_config, 'additional_filters' ) ? '' : 'display:none;' ?>"><?php esc_html_e( 'This requires Javascript to be enabled.', 'gfchart-time' ); ?></div>
		</td>
	</tr>

	</tbody>

</table>