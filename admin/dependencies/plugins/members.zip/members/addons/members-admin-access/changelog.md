# Change Log

## [1.0.1] - 2018-08-22

### Fixed

- Disables WooCommerce's admin redirect since this plugin is handling it.
- Don't redirect when performing an admin Ajax action from the front end.

## [1.0.0] - 2018-02-08

### Added

* Plugin launch.  Everything's new!
