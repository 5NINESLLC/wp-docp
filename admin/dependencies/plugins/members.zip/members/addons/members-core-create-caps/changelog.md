# Change Log

## [1.0.0] - 2017-12-11

### Added

* Plugin launch.  Everything's new!
