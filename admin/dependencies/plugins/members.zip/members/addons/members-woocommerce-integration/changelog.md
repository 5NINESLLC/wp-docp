# Change Log

## [1.0.0] - 2019-08-16

### Added

- Plugin launch.  Everything's new!
