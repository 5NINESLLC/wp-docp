<?php

//Silence is golden