<?php
/**
 * GFChart Configuration Metabox — Design Tab — Calculation Chart Type Basic Settings
 */
?>
<h1><?php _e( 'Calculation', 'gfchart' )?></h1>
No design settings for this chart type