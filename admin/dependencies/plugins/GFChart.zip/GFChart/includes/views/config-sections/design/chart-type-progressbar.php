<?php
/**
 * GFChart Configuration Metabox — Design Tab — Progress Bar Chart Type Basic Settings
 */
?>
<h1><?php _e( 'Progress Bar', 'gfchart' )?></h1>
No design settings for this chart type