<?php
/**
 * GFChart Configuration Metabox — Preview Tab
 */
?>
<div id="gfchart-config-section-preview">

	<!--<div id="gfchart-pie-preview" class="gfchart-preview" style="display:none;"></div>

	<div id="gfchart-bar-preview" class="gfchart-preview" style="display:none;"></div>

	<div id="gfchart-line-preview" class="gfchart-preview" style="display:none;"></div>

	<div id="gfchart-calc-preview" class="gfchart-preview" style="display:none;"></div>-->

</div>
