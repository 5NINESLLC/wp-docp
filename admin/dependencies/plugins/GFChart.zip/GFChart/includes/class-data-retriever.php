<?php
/* @package   GFChart\GFChart_Data_Retriever
 * @copyright 2015-2019 gravity+
 * @license   GPL-2.0+
 * @since     0.7
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class GFChart_Data_Retriever
 *
 * Retrieves data for chart render
 *
 * @since  0.7
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
class GFChart_Data_Retriever {

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $gfchart_config
	 * @param $source_form_id
	 * @param $filters
	 *
	 * @return array|string
	 */
	public function get_pie_chart_data( $gfchart_config, $source_form_id, $filters ) {

		global $wpdb;

		$field_id = $gfchart_config['source-field'];

		$data = array();


		$user_condition = GFChart_API::get_user_condition( $gfchart_config );

		$payment_status_condition = GFChart_API::get_payment_status_condition( $gfchart_config );

		$date_condition = GFChart_API::get_date_condition( $gfchart_config );

		// GF 2.3
		$old_schema = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' );

		$entry_table = $old_schema ? GFFormsModel::get_lead_table_name() : GFFormsModel::get_entry_table_name();

		$entry_details_table = $old_schema ? GFFormsModel::get_lead_details_table_name() : GFFormsModel::get_entry_meta_table_name();

		$lead_id_column_name = $old_schema ? 'lead_id' : 'entry_id';

		$field_id_column = $old_schema ? 'field_number' : 'meta_key';

		$field_value_column = $old_schema ? 'value' : 'meta_value';

		$field_where_clause = ( false === strpos( $field_id, '.' ) ) ? "{$field_id_column} = %d" : "FORMAT({$field_id_column}, 1) = FORMAT(%.1f, 1)";

		if ( empty( $filters['filters'] ) ) {

			$sql = $wpdb->prepare( "SELECT {$field_value_column}
					                                                FROM {$entry_details_table}
					                                                WHERE form_id = %d
					                                                AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status = 'active' {$user_condition} {$payment_status_condition} {$date_condition} )
					                                                AND {$field_where_clause}", $source_form_id, $field_id );

			$results = $wpdb->get_results( $sql, ARRAY_A );

			if ( empty( $results ) ) {

				return __( 'No data.' );

			}

			foreach ( $results as $key => $result ) {

				$results[ $key ] = ( false !== strpos( $result[ $field_value_column ], '|' ) ) ? strstr( $result[ $field_value_column ], '|', true ) : $result[ $field_value_column ];

			}

			foreach ( $results as $result ) {

				$data[ $result ] = ( array_key_exists( $result, $data ) ) ? $data[ $result ] + 1 : 1;

			}

		} else {

			$field_conditions = GFChart_API::get_field_conditions( $filters, $source_form_id );

			$distinct = '';

			if ( ( 'any' == $filters['mode'] ) || ( 'all' == $filters['mode'] && 1 == count( $filters['filters'] ) ) ) {

				$distinct = 'DISTINCT';

			}

			$sql = $wpdb->prepare( "SELECT {$distinct} {$lead_id_column_name} from {$entry_details_table} WHERE form_id=%d AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status= 'active' {$user_condition} {$payment_status_condition} {$date_condition} ) AND {$field_conditions}", $source_form_id );


			$results = $wpdb->get_results( $sql, ARRAY_A );

			if ( empty( $results ) ) {

				return __( 'No data.' );

			}

			foreach ( $results as $result ) {

				$entries[] = $result[ $lead_id_column_name ];

			}

			if ( empty( $entries ) ) {

				return __( 'No data.' );

			}

			foreach ( $entries as $entry_id ) {

				$sql = $wpdb->prepare( "SELECT {$field_value_column} FROM {$entry_details_table} WHERE {$lead_id_column_name} = %d AND {$field_where_clause}", $entry_id, $field_id );

				$value = $wpdb->get_var( $sql );

				if ( ! empty( $value ) ) {

					if ( false !== strpos( $value, '|' ) ) {

						$value = strstr( $value, '|', true );

					}

					$data[ $value ] = ( array_key_exists( $value, $data ) ) ? $data[ $value ] + 1 : 1;

				}

			}

		}

		$data  = apply_filters( 'gfchart_data_retriever_pre_convert_survey_field_data', $data, $gfchart_config, $source_form_id );

		$data = $this->convert_survey_field_data( $field_id, $source_form_id, $data, 'pie' );


		return apply_filters( 'gfchart_data_retriever_get_pie_chart_data', $data, $gfchart_config, $source_form_id );

	}

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $gfchart_config
	 * @param $source_form_id
	 * @param $filters
	 *
	 * @return array|string
	 */
	public function get_bar_chart_data( $gfchart_config, $source_form_id, $filters ) {

		$source_field_id = $gfchart_config['xaxis-main-field'];

		$data = array();

		$user_condition = GFChart_API::get_user_condition( $gfchart_config );

		$payment_status_condition = GFChart_API::get_payment_status_condition( $gfchart_config );

		$date_condition = GFChart_API::get_date_condition( $gfchart_config );


		$filtered = ! empty( $filters['filters'] );

		$segmented = ! empty( $gfchart_config['xaxis-segment-field'] );

		if ( $filtered ) {

			$data = $this->get_filtered_chart_data( $source_form_id, $source_field_id, $user_condition, $payment_status_condition, $date_condition, $filters, empty( $gfchart_config['xaxis-segment-field'] ) ? 0 : $gfchart_config['xaxis-segment-field'] );

		} else {

			$data = $this->get_unfiltered_chart_data( $source_form_id, $source_field_id, $user_condition, $payment_status_condition, $date_condition, empty( $gfchart_config['xaxis-segment-field'] ) ? 0 : $gfchart_config['xaxis-segment-field'] );

		}

		if ( empty( $data ) || ! is_array( $data ) ) {

			return $data;

		}

		if ( ! $segmented ) {

			$data = $this->convert_survey_field_data( $source_field_id, $source_form_id, $data, 'bar' );

		}

		$form = GFAPI::get_form( $source_form_id );

		$field = RGFormsModel::get_field( $form, $source_field_id );

		if ( ( is_object( $field ) && $field->type !== 'survey' ) || ( 'rank' !== $field->inputType ) ) {

			if ( ! empty( $gfchart_config['xaxis-sum-field'] ) ) {

				$data = $this->add_sum_field_value_to_results( $data, $gfchart_config['xaxis-sum-field'] );

			}

			if ( 'count' == $gfchart_config['yaxis'] ) {

				$data = $this->count_results( $data, $segmented );

			} else {

				$data = $this->sum_results( $data, $segmented );

			}

			if ( ! empty( $gfchart_config['show_zero_values'] ) ) {

				$data = $this->add_zero_values( $data, $source_form_id, $source_field_id );

			}

		}

		$sortby    = empty( $gfchart_config['sortby'] ) ? 'label' : $gfchart_config['sortby'];
		$sort_type = empty( $gfchart_config['sort_type'] ) ? 'asc' : $gfchart_config['sort_type'];

		$data = $this->sort_results( $data, $sortby, $sort_type );

		$data = $this->collapse_data( $data, $gfchart_config );


		return apply_filters( 'gfchart_data_retriever_get_bar_chart_data', $data, $gfchart_config, $source_form_id );

	}

	/**
	 * Get calculation chart data from the DB
	 *
	 * @since  0.8
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $gfchart_config
	 * @param $source_form_id
	 * @param $filters
	 *
	 * @return array|null|object|string
	 */
	public function get_calc_chart_data( $gfchart_config, $source_form_id, $filters ) {

		$source_field_id = $gfchart_config['source-field'];

		$data = array();


		$user_condition = GFChart_API::get_user_condition( $gfchart_config );

		$payment_status_condition = GFChart_API::get_payment_status_condition( $gfchart_config );

		$date_condition = GFChart_API::get_date_condition( $gfchart_config );


		$filtered = ! empty( $filters['filters'] );

		if ( $filtered ) {

			$data = $this->get_filtered_chart_data( $source_form_id, $source_field_id, $user_condition, $payment_status_condition, $date_condition, $filters, 0 );

		} else {

			$data = $this->get_unfiltered_chart_data( $source_form_id, $source_field_id, $user_condition, $payment_status_condition, $date_condition, 0 );

		}

		if ( empty( $data ) || ! is_array( $data ) ) {

			return array( 0 );

		}

		$number_of_items = count( $data );

		if ( 'count' == $gfchart_config['calculation'] ) {

			$data = $number_of_items;

		} else if ( 'count_unique' == $gfchart_config['calculation'] ) {

			$field_value_column = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' ) ? 'value' : 'meta_value';

			$values = array();

			foreach ( $data as $result ) {

				$values[] = $result[ $field_value_column ];

			}


			$data = count( array_unique( $values ) );

		} else {

			$total = 0;

			$field_value_column = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' ) ? 'value' : 'meta_value';


			foreach ( $data as $result ) {

				if ( false !== strpos( $result[ $field_value_column ], '|' ) ) {

					$result = explode( '|', $result[ $field_value_column ] );

					$total += $result[1];

				} else {

					$total += $result[ $field_value_column ];

				}

			}

			$data = ( 'avg' == $gfchart_config['calculation'] ) ? $total / $number_of_items : $total;

		}


		return array( $data );

	}

	/**
	 * @since  1.0.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $gfchart_config
	 * @param $source_form_id
	 * @param $filters
	 *
	 * @return array
	 */
	public function get_progressbar_chart_data( $gfchart_config, $source_form_id, $filters ) {

		global $gfp_gfchart;

		$progress = array( 'total' => 0, 'goal' => 0, 'percent' => 0 );

		$calc_chart_id = $gfchart_config['calc-chart'];

		if ( ! empty( $calc_chart_id ) ) {

			$calc_chart_config = get_post_meta( $calc_chart_id, '_gfchart_config', true );

			$calc_chart_source_form_id = get_post_meta( $calc_chart_id, 'source_form', true );

			if ( ! empty( $gfp_gfchart->shortcode_args['calc_filter_field'] ) && ! empty( $gfp_gfchart->shortcode_args['calc_filter_condition'] ) && ! empty( $gfp_gfchart->shortcode_args['calc_filter_value'] ) ) {

				$calc_chart_filters = array(
					'filters' => array(
						array(
							'key'      => $gfp_gfchart->shortcode_args['calc_filter_field'],
							'field'    => $gfp_gfchart->shortcode_args['calc_filter_field'],
							'operator' => $gfp_gfchart->shortcode_args['calc_filter_condition'],
							'value'    => $gfp_gfchart->shortcode_args['calc_filter_value']
						)
					),
					'mode'    => 'all'
				);
			} else {

				$calc_chart_filters = GFChart_API::get_gfchart_filter_vars( $calc_chart_id, true );

			}

			$calc_chart_data = array();

			$calc_chart_data = call_user_func( array(
				$gfp_gfchart->get_data_object(),
				"get_{$calc_chart_config['chart_type']}_chart_data"
			), $calc_chart_config, $calc_chart_source_form_id, $calc_chart_filters );

			if ( ! empty( $calc_chart_data ) && is_array( $calc_chart_data ) && ! empty( $gfchart_config['goal'] ) ) {

				//$calc_chart_value = GFCommon::clean_number( $calc_chart_data[0] );
				$calc_chart_value = GFCommon::clean_number( round($calc_chart_data[0],2) );

				$goal = empty( $gfp_gfchart->shortcode_args['goal'] ) ? GFCommon::clean_number( $gfchart_config['goal'] ) : GFCommon::clean_number( $gfp_gfchart->shortcode_args['goal'] );

				$progress = array(
					'total'   => $calc_chart_value,
					'goal'    => $goal,
					'percent' => ( $calc_chart_value <= $goal ) ? floor( ( $calc_chart_value / $goal ) * 100 ) : 100
				);

			}

		}


		return $progress;

	}

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param     $source_form_id
	 * @param     $source_field_id
	 * @param     $user_condition
	 * @param     $date_condition
	 * @param int $segment_field_id
	 *
	 * @return array|null|object|string|void
	 */
	private function get_unfiltered_chart_data( $source_form_id, $source_field_id, $user_condition, $payment_status_condition, $date_condition, $segment_field_id = 0 ) {

		global $wpdb;

		$form = GFAPI::get_form( $source_form_id );

		// GF 2.3
		$old_schema = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' );

		$entry_table = $old_schema ? GFFormsModel::get_lead_table_name() : GFFormsModel::get_entry_table_name();

		$entry_details_table = $old_schema ? GFFormsModel::get_lead_details_table_name() : GFFormsModel::get_entry_meta_table_name();

		$lead_id_column_name = $old_schema ? 'lead_id' : 'entry_id';

		$field_id_column = $old_schema ? 'field_number' : 'meta_key';

		$field_value_column = $old_schema ? 'value' : 'meta_value';


		if ( empty( $segment_field_id ) ) {

			if ( ! empty( $source_field_id ) ) {

				$field = RGFormsModel::get_field( $form, $source_field_id );

				$field_number_sql = ( 'checkbox' == $field->type ) ? 'LIKE \'%d.%%\'' : ( ( false === strpos( $source_field_id, '.' ) ) ? '= %d' : "= FORMAT(%.1f, 1)" );

				$field_where_clause = ( false === strpos( $source_field_id, '.' ) ) ? "{$field_id_column} {$field_number_sql}" : "FORMAT({$field_id_column}, 1) {$field_number_sql}";

				$sql = $wpdb->prepare( "SELECT {$lead_id_column_name}, {$field_value_column}
									FROM {$entry_details_table}
									WHERE form_id = %d
									AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status = 'active' {$user_condition} {$payment_status_condition} {$date_condition} )
									AND {$field_where_clause}", $source_form_id, $source_field_id );

			} else {

				$sql = $wpdb->prepare( "SELECT id FROM {$entry_table} WHERE form_id = %d AND status = 'active' {$user_condition} {$payment_status_condition} {$date_condition}", $source_form_id );

			}

		} else {

			$field = RGFormsModel::get_field( $form, $source_field_id );

			$field_number_sql = 'checkbox' == $field->type ? 'LIKE \'%d.%%\'' : '= %d';

			$sql = $wpdb->prepare( "SELECT p2.{$lead_id_column_name}, p2.{$field_value_column} main, p1.{$field_value_column} segment FROM {$entry_details_table} p1 INNER JOIN ( SELECT {$lead_id_column_name}, {$field_value_column}
					                                                FROM {$entry_details_table}
					                                                WHERE form_id = %d
					                                                AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status = 'active' {$user_condition} {$payment_status_condition} {$date_condition} )
					                                                AND {$field_id_column} {$field_number_sql} ) p2 ON p1.{$lead_id_column_name} = p2.{$lead_id_column_name} WHERE {$field_id_column} = %d", $source_form_id, $source_field_id, $segment_field_id );

		}

		$results = $wpdb->get_results( $sql, ARRAY_A );

		if ( empty( $results ) ) {

			$data = __( 'No data.' );

		} else {

			$data = $results;

		}


		return $data;
	}

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param     $source_form_id
	 * @param     $source_field_id
	 * @param     $user_condition
	 * @param     $date_condition
	 * @param     $filters
	 *
	 * @param int $segment_field_id
	 *
	 * @return array|string|void
	 */
	private function get_filtered_chart_data( $source_form_id, $source_field_id, $user_condition, $payment_status_condition, $date_condition, $filters, $segment_field_id = 0 ) {

		global $wpdb;

		$data = array();


		$form = GFAPI::get_form( $source_form_id );

		$field_conditions = GFChart_API::get_field_conditions( $filters, $source_form_id );

		$distinct = '';

		if ( ( 'any' == $filters['mode'] ) || ( 'all' == $filters['mode'] && 1 == count( $filters['filters'] ) ) ) {

			$distinct = 'DISTINCT';

		}


		// GF 2.3
		$old_schema = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' );

		$entry_table = $old_schema ? GFFormsModel::get_lead_table_name() : GFFormsModel::get_entry_table_name();

		$entry_details_table = $old_schema ? GFFormsModel::get_lead_details_table_name() : GFFormsModel::get_entry_meta_table_name();

		$lead_id_column_name = $old_schema ? 'lead_id' : 'entry_id';

		$field_id_column = $old_schema ? 'field_number' : 'meta_key';

		$field_value_column = $old_schema ? 'value' : 'meta_value';


		if ( empty( $segment_field_id ) ) {

			if ( ! empty( $source_field_id ) ) {

				$field = RGFormsModel::get_field( $form, $source_field_id );

				$field_number_sql = ( 'checkbox' == $field->type ) ? 'LIKE \'%d.%%\'' : ( ( false === strpos( $source_field_id, '.' ) ) ? '= %d' : "= FORMAT(%.1f, 1)" );

				$field_where_clause = ( false === strpos( $source_field_id, '.' ) ) ? "{$field_id_column} {$field_number_sql}" : "FORMAT({$field_id_column}, 1) {$field_number_sql}";


				$sql = $wpdb->prepare( "SELECT p2.{$lead_id_column_name}, p2.{$field_value_column} FROM {$entry_details_table} p2 INNER JOIN ( SELECT {$distinct} {$lead_id_column_name} from {$entry_details_table} WHERE form_id=%d AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status= 'active' {$user_condition} {$payment_status_condition} {$date_condition} ) AND {$field_conditions} ) p1 ON p1.{$lead_id_column_name} = p2.{$lead_id_column_name} WHERE {$field_where_clause}", $source_form_id, $source_field_id );

			} else {

				$sql = $wpdb->prepare( "SELECT {$distinct} {$lead_id_column_name} from {$entry_details_table} WHERE form_id=%d AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status= 'active' {$user_condition} {$payment_status_condition} {$date_condition} ) AND {$field_conditions}", $source_form_id );
			}

		} else {

			$field = RGFormsModel::get_field( $form, $source_field_id );

			$field_number_sql = 'checkbox' == $field->type ? 'LIKE \'%d.%%\'' : '= %d';

			$sql = $wpdb->prepare( "SELECT p3.{$lead_id_column_name} {$lead_id_column_name}, p3.main main, p4.{$field_value_column} segment
			FROM {$entry_details_table} p4
			INNER JOIN( SELECT p1.{$lead_id_column_name} {$lead_id_column_name}, p2.{$field_value_column} main
			FROM {$entry_details_table} p2
			INNER JOIN ( SELECT {$distinct} {$lead_id_column_name} from {$entry_details_table} WHERE form_id=%d AND {$lead_id_column_name} IN ( SELECT id FROM {$entry_table} WHERE status= 'active' {$user_condition} {$payment_status_condition} {$date_condition} ) AND {$field_conditions} ) p1
			ON p1.{$lead_id_column_name} = p2.{$lead_id_column_name}
			WHERE {$field_id_column} {$field_number_sql} ) p3
			ON p3.{$lead_id_column_name} = p4.{$lead_id_column_name}
			AND {$field_id_column} = %d", $source_form_id, $source_field_id, $segment_field_id );

		}

		$results = $wpdb->get_results( $sql, ARRAY_A );

		if ( empty( $results ) ) {

			$data = __( 'No data.', 'gfchart' );

		} else {

			$data = $results;

		}

		return $data;

	}

	/**
	 * @since
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $lead_ids
	 * @param $sum_field_id
	 *
	 * @return array|string|void
	 */
	public function get_sum_field_values( $lead_ids, $sum_field_id ) {

		global $wpdb;

		$sum_field_values = array();

		$lead_ids = implode( ',', $lead_ids );


		$old_schema = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' );

		$entry_table = $old_schema ? GFFormsModel::get_lead_table_name() : GFFormsModel::get_entry_table_name();

		$entry_details_table = $old_schema ? GFFormsModel::get_lead_details_table_name() : GFFormsModel::get_entry_meta_table_name();

		$lead_id_column_name = $old_schema ? 'lead_id' : 'entry_id';

		$field_id_column = $old_schema ? 'field_number' : 'meta_key';

		$field_value_column = $old_schema ? 'value' : 'meta_value';


		$sql = $wpdb->prepare( "SELECT {$lead_id_column_name}, {$field_value_column} from {$entry_details_table} WHERE {$lead_id_column_name} IN (" . $lead_ids . ") AND {$field_id_column} = %d", $sum_field_id );

		$results = $wpdb->get_results( $sql, ARRAY_A );

		if ( empty( $results ) ) {

			$sum_field_values = __( 'No data.', 'gfchart' );

		} else {

			foreach ( $results as $result ) {

				$sum_field_values[ $result[ $lead_id_column_name ] ] = $result[ $field_value_column ];

			}

		}

		return $sum_field_values;
	}

	/**
	 * @since
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $results
	 * @param $sum_field_id
	 *
	 * @return mixed
	 */
	public function add_sum_field_value_to_results( $results, $sum_field_id ) {

		$lead_ids = array();


		$old_schema = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' );

		$lead_id_column_name = $old_schema ? 'lead_id' : 'entry_id';


		foreach ( $results as $result ) {

			$lead_ids[] = $result[ $lead_id_column_name ];

		}

		unset( $result );

		$sum_field_values = $this->get_sum_field_values( $lead_ids, $sum_field_id );

		if ( ! empty( $sum_field_values ) && is_array( $sum_field_values ) ) {

			foreach ( $results as $key => $result ) {

				$results[ $key ]['sum_value'] = empty( $sum_field_values[ $result[ $lead_id_column_name ] ] ) ? 0 : $sum_field_values[ $result[ $lead_id_column_name ] ];

			}

		}

		return $results;

	}

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $results
	 *
	 * @return array
	 */
	public function count_results( $results, $segmented = false ) {

		$data = array( 'segments' => array(), 'results' => array() );

		// GF 2.3
		$field_value_column = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' ) ? 'value' : 'meta_value';

		if ( $segmented ) {

			foreach ( $results as $result ) {

				if ( false !== strpos( $result['main'], '|' ) ) {

					$result['main'] = strstr( $result['main'], '|', true );

				}

				if ( false !== strpos( $result['segment'], '|' ) ) {

					$result['segment'] = strstr( $result['segment'], '|', true );

				}

				if ( array_key_exists( $result['main'], $data['results'] ) ) {

					if ( array_key_exists( $result['segment'], $data['results'][ $result['main'] ] ) ) {

						$data['results'][ $result['main'] ][ $result['segment'] ] = $data['results'][ $result['main'] ][ $result['segment'] ] + 1;

					} else {

						$data['results'][ $result['main'] ][ $result['segment'] ] = 1;

					}

				} else {

					$data['results'][ $result['main'] ][ $result['segment'] ] = 1;

				}

				if ( ! in_array( $result['segment'], $data['segments'] ) ) {

					$data['segments'][] = $result['segment'];
				}

			}

		} else {

			foreach ( $results as $result ) {

				if ( false !== strpos( $result[ $field_value_column ], '|' ) ) {

					$result = strstr( $result[ $field_value_column ], '|', true );

				} else if ( false !== strpos( $result[ $field_value_column ], ',' ) ) {

					$multiselect_values = explode( ',', $result[ $field_value_column ] );

					foreach ( $multiselect_values as $multiselect_value ) {

						if ( array_key_exists( $multiselect_value, $data['results'] ) ) {

							$data['results'][ $multiselect_value ] = $data['results'][ $multiselect_value ] + 1;

						} else {

							$data['results'][ $multiselect_value ] = 1;

						}

					}

					continue;

				} else {

					$result = $result[ $field_value_column ];

				}

				if ( array_key_exists( $result, $data['results'] ) ) {

					$data['results'][ $result ] = $data['results'][ $result ] + 1;

				} else {

					$data['results'][ $result ] = 1;

				}

			}

		}


		return $data;
	}

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $results
	 *
	 * @return array
	 */
	public function sum_results( $results, $segmented = false ) {

		$data = array( 'segments' => array(), 'results' => array() );

		if ( $segmented ) {

			foreach ( $results as $result ) {

				if ( false !== strpos( $result['main'], '|' ) ) {

					$result['main'] = explode( '|', $result['main'] );

				} else {

					$result['main'] = array( $result['main'], $result['main'] );
				}

				if ( false !== strpos( $result['segment'], '|' ) ) {

					$result['segment'] = explode( '|', $result['segment'] );

				} else {

					$result['segment'] = array( $result['segment'], $result['segment'] );

				}

				$main_label = $result['main'][0];

				$segment_label = $result['segment'][0];

				$value = array_key_exists( 'sum_value', $result ) ? $result['sum_value'] : $result['main'][1];

				if ( array_key_exists( $main_label, $data['results'] ) ) {

					if ( array_key_exists( $segment_label, $data['results'][ $main_label ] ) ) {

						$data['results'][ $main_label ][ $segment_label ] += $value;

					} else {

						$data['results'][ $main_label ][ $segment_label ] = $value;

					}

				} else {

					$data['results'][ $main_label ][ $segment_label ] = $value;

				}

				if ( ! in_array( $segment_label, $data['segments'] ) ) {

					$data['segments'][] = $segment_label;
				}

				unset( $main_label, $segment_label, $value );

			}


		} else {

			// GF 2.3
			$field_value_column = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' ) ? 'value' : 'meta_value';


			foreach ( $results as $result ) {

				if ( false !== strpos( $result[ $field_value_column ], '|' ) ) {

					$result_value = explode( '|', $result[ $field_value_column ] );

					$label = $result_value[0];

					$value = array_key_exists( 'sum_value', $result ) ? $result['sum_value'] : $result_value[1];

					if ( array_key_exists( $label, $data['results'] ) ) {

						$data['results'][ $label ] += $value;

					} else {

						$data['results'][ $label ] = $value;

					}

				} else {

					$label = $result[ $field_value_column ];

					$value = array_key_exists( 'sum_value', $result ) ? $result['sum_value'] : $result[ $field_value_column ];


					if ( array_key_exists( $label, $data['results'] ) ) {

						$data['results'][ $label ] += $value;

					} else {

						$data['results'][ $label ] = $value;

					}

				}

				unset( $result_value, $label, $value );

			}

		}


		return $data;
	}

	/**
	 * Add zero values to results
	 *
	 * @since  1.1.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $data
	 *
	 * @return mixed
	 */
	public function add_zero_values( $data, $form_id, $source_field_id ) {

		$field_choices = GFChart_API::get_field_choices( $form_id, $source_field_id );

		if ( ! empty( $field_choices ) ) {

			if ( empty( $data['segments'] ) ) {


				foreach ( $field_choices as $choice ) {

					if ( ! array_key_exists( $choice['text'], $data['results'] ) ) {

						$data['results'][ $choice['text'] ] = '0';

					}

				}

			} else {

				foreach ( $field_choices as $choice ) {

					if ( ! array_key_exists( $choice['text'], $data['results'] ) ) {

						$data['results'][ $choice['text'] ] = array();

						foreach ( $data['segments'] as $segment ) {

							$data['results'][ $choice['text'] ][ $segment ] = '0';

						}

					}

				}


			}
		}

		return $data;
	}

	/**
	 * Sort bar chart results
	 *
	 * @since  1.0.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param array  $data
	 * @param string $sortby    Whether to sort by label or value
	 * @param string $sort_type ascending or descending order
	 *
	 * @return array
	 */
	public function sort_results( $data, $sortby, $sort_type ) {

		if ( 'label' == $sortby ) {

			switch ( $sort_type ) {

				case 'asc':

					ksort( $data['results'] );


					break;

				case 'desc':

					krsort( $data['results'] );


					break;

			}

		} else if ( 'value' == $sortby ) {

			$segmented = ! empty( $data['segments'] );

			if ( $segmented ) {

				$main_field_totals = array();

				foreach ( $data['results'] as $main_field => $segment ) {

					$main_field_totals[ $main_field ] = array_sum( $segment );

				}

			}

			switch ( $sort_type ) {

				case 'asc':

					if ( $segmented ) {

						version_compare( phpversion(), '5.4.0', '>=' ) ? asort( $main_field_totals, SORT_NATURAL | SORT_FLAG_CASE ) : asort( $main_field_totals );

					} else {

						version_compare( phpversion(), '5.4.0', '>=' ) ? asort( $data['results'], SORT_NATURAL | SORT_FLAG_CASE ) : asort( $data['results'] );

					}

					break;

				case 'desc':

					if ( $segmented ) {

						version_compare( phpversion(), '5.4.0', '>=' ) ? arsort( $main_field_totals, SORT_NATURAL | SORT_FLAG_CASE ) : arsort( $main_field_totals );

					} else {

						version_compare( phpversion(), '5.4.0', '>=' ) ? arsort( $data['results'], SORT_NATURAL | SORT_FLAG_CASE ) : arsort( $data['results'] );

					}

					break;

			}

			if ( $segmented ) {

				$former_data_results = $data['results'];

				$data['results'] = array();

				foreach ( $main_field_totals as $main_field => $total ) {

					$data['results'][ $main_field ] = $former_data_results[ $main_field ];

				}

			}

		}


		return $data;
	}

	/**
	 * @since  0.7
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $data
	 * @param $chart_config
	 *
	 * @return mixed
	 */
	public function collapse_data( $data, $chart_config ) {

		if ( ( ! empty( $data['segments'] ) ) && ( ! empty( $chart_config['xaxis-segment-max-entries'] ) ) && ( count( $data['segments'] ) > $chart_config['xaxis-segment-max-entries'] ) ) {

			$segment_count = count( $data['segments'] );

			$extra_entries = $chart_config['xaxis-segment-max-entries'] - $segment_count;

			array_splice( $data['segments'], $extra_entries );


			foreach ( $data['results'] as $label => $segment_data ) {

				$data['results'][ $label ]['Other'] = 0;

				foreach ( $segment_data as $segment_label => $segment_value ) {

					if ( ! in_array( $segment_label, $data['segments'] ) ) {

						$data['results'][ $label ]['Other'] += $segment_value;

						unset( $data['results'][ $label ][ $segment_label ] );

					}

				}

			}

			$data['segments'][] = 'Other';

		}

		if ( ( ! empty( $chart_config['xaxis-main-max-entries'] ) ) && ( count( $data['results'] ) > $chart_config['xaxis-main-max-entries'] ) ) {

			$data_count = count( $data['results'] );

			$extra_entries = $chart_config['xaxis-main-max-entries'] - $data_count;

			$addl_data = array_slice( $data['results'], $extra_entries, null, true );

			array_splice( $data['results'], $extra_entries );

			if ( empty( $data['segments'] ) ) {

				$data['results']['Other'] = array_sum( $addl_data );

			} else {

				$data['results']['Other'] = array();

				foreach ( $addl_data as $segment_label => $segment_value ) {

					if ( array_key_exists( $segment_label, $data['results']['Other'] ) ) {

						$data['results']['Other'][ $segment_label ] += $segment_value;

					} else {

						$data['results']['Other'][ $segment_label ] = $segment_value;

					}

				}

			}

		}


		return $data;
	}

	/**
	 * Convert results data if this was a survey field
	 *
	 * @since  1.2.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $field_id
	 * @param $form_id
	 * @param $data
	 *
	 * @return mixed
	 */
	private function convert_survey_field_data( $field_id, $form_id, $data, $chart_type ) {

		$form = GFAPI::get_form( $form_id );

		$field = RGFormsModel::get_field( $form, $field_id );

		if ( is_object( $field ) && $field->type == 'survey' ) {

			// GF 2.3
			$field_value_column = version_compare( GFFormsModel::get_database_version(), '2.3-dev-1', '<' ) ? 'value' : 'meta_value';

			switch ( $field->inputType ) {

				case 'radio' :
				case 'checkbox' :
				case 'select' :
				case 'rating' :
					/*case 'multiselect' :
						break;*/
				case 'likert' :

					if ( 'pie' == $chart_type ) {

						foreach ( $data as $label => $number ) {

							$true_label = RGFormsModel::get_choice_text( $field, $label );

							$new_data[ $true_label ] = $number;

						}

						$data = empty( $new_data ) ? $data : $new_data;

					} else if ( 'bar' == $chart_type ) {

						foreach ( $data as $key => $result ) {

							$true_value = RGFormsModel::get_choice_text( $field, $result[ $field_value_column ] );

							$data[ $key ][ $field_value_column ] = $true_value;

						}

					}

					break;

				case 'rank' :

					if ( 'bar' == $chart_type ) {

						$new_data = array();

						foreach ( $data as $key => $result ) {

							$score = count( rgar( $field, 'choices' ) );

							$values = explode( ',', $result[ $field_value_column ] );

							foreach ( $values as $ranked_value ) {

								$label = RGFormsModel::get_choice_text( $field, $ranked_value );

								if ( array_key_exists( $label, $new_data ) ) {

									$new_data[ $label ] += $score;

								} else {

									$new_data[ $label ] = $score;

								}

								$score --;

							}

						}

						$data['results'] = empty( $new_data ) ? $data['results'] : $new_data;

					}

			}

		}

		return $data;
	}

}