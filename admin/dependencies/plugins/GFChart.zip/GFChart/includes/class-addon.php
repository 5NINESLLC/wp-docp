<?php
/*
 * @package   GFChart\GFChart_Addon
 * @copyright 2015-2019 gravity+
 * @license   GPL-2.0+
 * @since     0.53
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


/**
 * Class GFChart_Addon
 *
 * Gravity Forms Add-On Framework settings
 *
 * @since
 *
 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
 */
class GFChart_Addon extends GFAddOn {

	/**
	 * @var string Version number of the Add-On
	 */
	protected $_version;
	/**
	 * @var string Gravity Forms minimum version requirement
	 */
	protected $_min_gravityforms_version;
	/**
	 * @var string URL-friendly identifier used for form settings, add-on settings, text domain localization...
	 */
	protected $_slug;
	/**
	 * @var string Relative path to the plugin from the plugins folder
	 */
	protected $_path;
	/**
	 * @var string Full path to the plugin. Example: __FILE__
	 */
	protected $_full_path;
	/**
	 * @var string URL to the App website.
	 */
	protected $_url;
	/**
	 * @var string Title of the plugin to be used on the settings page, form settings and plugins page.
	 */
	protected $_title;
	/**
	 * @var string Short version of the plugin title to be used on menus and other places where a less verbose string is useful.
	 */
	protected $_short_title;
	/**
	 * @var array Members plugin integration. List of capabilities to add to roles.
	 */
	protected $_capabilities = array();

	// ------------ Permissions -----------
	/**
	 * @var string|array A string or an array of capabilities or roles that have access to the settings page
	 */
	protected $_capabilities_settings_page = array();

	/**
	 * @var string|array A string or an array of capabilities or roles that have access to the plugin page
	 */
	protected $_capabilities_plugin_page = array();
	/**
	 * @var string|array A string or an array of capabilities or roles that can uninstall the plugin
	 */
	protected $_capabilities_uninstall = array();

	function __construct( $args ) {

		$this->_version                    = $args[ 'version' ];
		$this->_slug                       = $args[ 'plugin_slug' ];
		$this->_min_gravityforms_version   = $args[ 'min_gf_version' ];
		$this->_path                       = $args[ 'path' ];
		$this->_full_path                  = $args[ 'full_path' ];
		$this->_url                        = $args[ 'url' ];
		$this->_title                      = $args[ 'title' ];
		$this->_short_title                = $args[ 'short_title' ];
		$this->_capabilities               = $args[ 'capabilities' ];
		$this->_capabilities_settings_page = $args[ 'capabilities_settings_page' ];
		$this->_capabilities_plugin_page   = $args[ 'capabilities_plugin_page' ];
		$this->_capabilities_uninstall     = $args[ 'capabilities_uninstall' ];

		parent::__construct();

	}

	public function init_admin() {

		$license_key = trim( $this->get_plugin_setting( 'license_key' ) );

		if ( ! empty( $license_key ) ) {

			$edd_updater = new EDD_SL_Plugin_Updater( GFCHART_EDD_STORE_URL, GFCHART_FILE, array(
				                                                               'version'   => GFCHART_CURRENT_VERSION,
				                                                               'license'   => $license_key,
				                                                               'item_name' => GFCHART_EDD_ITEM_NAME,
				                                                               'item_id' => GFCHART_EDD_ITEM_ID,
				                                                               'author'    => 'Mensard with gravity+'
			                                                               )
			);

		}

		parent::init_admin();

	}

	public function plugin_settings_fields() {

		$settings_fields = array();

		$settings_fields[ ] = array(
			'title'       => __( 'License', 'gfchart' ),
			'description' => __( 'This provides you access to support and automatic updates', 'gfchart' ),
			'fields'      => array(
				array(
					'name'                => 'license_key',
					'tooltip'             => __( 'Enter your license key that was emailed with your purchase.', 'gfchart' ),
					'label'               => __( 'License Key', 'gfchart' ),
					'type'                => 'text',
					'validation_callback' => array( $this, 'validate_license_key' ),
					'feedback_callback'   => array( $this, 'check_license_key' ),
					'class'               => ( '' == $this->get_plugin_setting( 'license_key' ) ) ? 'activate' : 'deactivate',
				),
				array(
					'type'     => 'save',
					'value'    => ( '' == $this->get_plugin_setting( 'license_key' ) ) ? __( 'Activate', 'gfchart' ) : __( 'Deactivate', 'gfchart' ),
					'messages' => array(
						'success' => __( 'License key updated', 'gfchart' )
					)
				)
			)
		);

		return $settings_fields;
	}

	/**
	 * Validate license key when settings are submitted
	 *
	 * @since  1.0.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $field
	 * @param $field_setting
	 */
	public function validate_license_key( $field, $field_setting ) {

		delete_option( 'gfchart_license_status' );

		if ( ! empty( $field_setting ) && ( 'activate' == $field[ 'class' ] ) ) {

			$activated = $this->activate_license( $field_setting );

			$error = $this->get_activation_error( $activated );

			if ( ! empty( $error ) ) {

				$this->set_field_error( $field, $error );

			}
			else {

				update_option( 'gfchart_license_status', $activated->license );
			}

		} else if ( ! empty( $field_setting ) && ( 'deactivate' == $field[ 'class' ] ) ) {

			$deactivated = $this->deactivate_license( $field_setting );

			$error = $this->get_deactivation_error( $deactivated );

			if ( ! empty( $error ) ) {

				$this->set_field_error( $field, $error );

			}

		} else if ( empty( $field_setting ) ) {

			$previous_settings = $this->get_previous_settings();

			if ( ! empty( $previous_settings[ 'license_key' ] ) ) {

				$deactivated = $this->deactivate_license( $previous_settings[ 'license_key' ] );

				$error = $this->get_deactivation_error( $deactivated );

				if ( ! empty( $error ) ) {

					$this->set_field_error( $field, $error );

				}

			}

		}

	}

	/**
	 * Check if license key is valid or not
	 *
	 * @since  1.0.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $license_key
	 * @param $field
	 *
	 * @return bool
	 */
	public function check_license_key( $license_key, $field ) {

	    if ( empty( $license_key ) ) {

	        return false;
        }

		$license_check_result = $this->check_license( $license_key );

	    if ( 'valid' == $license_check_result ) {

	        return true;
        }

        $this->log_error( __METHOD__ . ' ' . $license_check_result  );

		return false;
	}

	/**
	 * Activate GFChart license
	 *
	 * $license_data->license will be either "valid" or "invalid"
	 *
	 * @param $license
	 *
	 * @return bool
	 */
	private function activate_license( $license ) {

		$api_params = array(
			'edd_action' => 'activate_license',
			'license'    => $license,
			'item_name'  => urlencode( GFCHART_EDD_ITEM_NAME ),
			'item_id'    => GFCHART_EDD_ITEM_ID,
			'url'        => home_url()
		);

		$response = wp_remote_post( GFCHART_EDD_STORE_URL, array(
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => $api_params
		) );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			return false;

		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );


		return $license_data;

	}

	private function get_activation_error( $result ) {

		$activation_error = '';

		if ( empty( $result ) ) {

			$activation_error = __( 'Error receiving a response from license server', 'gfchart' );

		} 
		else if ( false === $result->success ) {

			switch( $result->error ) {

				case 'expired' :

					$activation_error = sprintf(
						__( 'Your license key expired on %s.', 'gfchart' ),
						date_i18n( get_option( 'date_format' ), strtotime( $result->expires, current_time( 'timestamp' ) ) )
					);
					
					break;

				case 'revoked' :

					$activation_error = __( 'Your license key has been disabled.', 'gfchart' );
					
					break;

				case 'missing' :

					$activation_error = __( 'Invalid license.', 'gfchart' );
					
					break;

				case 'invalid' :
				case 'site_inactive' :

					$activation_error = __( 'Your license is not active for this URL.', 'gfchart' );
					
					break;

				case 'item_name_mismatch' :

					$activation_error = sprintf( __( 'This appears to be an invalid license key for %s.', 'gfchart' ), GFCHART_EDD_ITEM_NAME );
					
					break;

				case 'no_activations_left':

					$activation_error = __( 'Your license key has reached its activation limit.', 'gfchart' );
					
					break;

				default :

					$activation_error = __( 'An error occurred, please try again.', 'gfchart' );
					
					break;
			
			}

		}

		return $activation_error;

	}

	private function get_deactivation_error( $result ) {

		$deactivation_error = '';

		if ( empty( $result ) ) {

			$deactivation_error = __( 'Error receiving a response from license server', 'gfchart' );

		} else if ( 'failed' == $result ) {

			$deactivation_error = __( 'Unable to deactivate key', 'gfchart' );

		} else if ( 'deactivated' !== $result ) {

			$deactivation_error = __( 'Unknown error', 'gfchart' );

		}

		return $deactivation_error;
	}

	/**
	 * Deactivate GFChart license
	 *
	 * $license_data->license will be either "deactivated" or "failed"
	 *
	 * @since  1.0.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $license
	 *
	 * @return bool
	 */
	private function deactivate_license( $license ) {

		$api_params = array(
			'edd_action' => 'deactivate_license',
			'license'    => $license,
			'item_name'  => urlencode( GFCHART_EDD_ITEM_NAME ),
			'item_id'    => GFCHART_EDD_ITEM_ID,
			'url'        => home_url()
		);

		$response = wp_remote_post( GFCHART_EDD_STORE_URL, array(
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => $api_params
		) );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );


		return $license_data->license;

	}

	/**
	 * Check whether license key is valid or not
	 *
	 * @since  1.0.0
	 *
	 * @author Naomi C. Bush for gravity+ <support@gravityplus.pro>
	 *
	 * @param $license
	 *
	 * @return string
	 */
	private function check_license( $license ) {

		$api_params = array(
			'edd_action' => 'check_license',
			'license'    => $license,
			'item_name'  => urlencode( GFCHART_EDD_ITEM_NAME ),
			'item_id'    => GFCHART_EDD_ITEM_ID,
			'url'        => home_url()
		);

		$response = wp_remote_post( GFCHART_EDD_STORE_URL, array(
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => $api_params
		) );


		if ( is_wp_error( $response ) ) {
			return false;
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );


		return $license_data->license;

	}

	/**
	 * Override this function to create a custom plugin page
	 */
	public function plugin_page() {
	}

	/**
	 * Creates plugin page menu item
	 * Target of gform_addon_navigation filter. Creates a menu item in the left nav, linking to the plugin page
	 *
	 * @param $menus - Current list of menu items
	 *
	 * @return array - Returns a new list of menu items
	 */
	public function create_plugin_page_menu( $menus ) {

		$menus[ ] = array(
			'name'       => $this->_slug,
			'label'      => 'Charts/Calculations',
			'callback'   => array( $this, 'plugin_page_container' ),
			'permission' => $this->_capabilities_plugin_page[0]
		);

		return $menus;
	}

	/**
	 * Plugin page container
	 * Target of the plugin menu left nav icon. Displays the outer plugin page markup and calls plugin_page() to render the actual page.
	 * Override plugin_page() in order to provide a custom plugin page
	 */
	public function plugin_page_container() {

		$gfchart_page = admin_url() . 'edit.php?post_type=gfchart';

		?>
		<script>location.href = '<?php echo $gfchart_page;?>';</script>
	<?php
	}

}