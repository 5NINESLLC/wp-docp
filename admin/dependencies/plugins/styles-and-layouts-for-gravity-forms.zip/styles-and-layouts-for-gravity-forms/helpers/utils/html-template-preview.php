<div class="stla-gravity-preview" id="stla-gravity-preview" style="width:80%; margin:auto; margin-top: 80px;">
    <?php echo do_shortcode('[gravityform id="'.$form_id.'" title="true" description="true"  ]'); ?>
</div>